import axios from 'axios';
import { User, Course, UserRole } from '../types';

const API_BASE_URL = 'https://iomad.bylinelms.com/webservice/rest/server.php';
const API_TOKEN = '4a2ba2d6742afc7d13ce4cf486ba7633';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// Add request interceptor to include token
api.interceptors.request.use((config) => {
  config.params = {
    ...config.params,
    wstoken: API_TOKEN,
    moodlewsrestformat: 'json',
  };
  return config;
});

// Mock role detection based on username patterns
const detectUserRole = (username: string): UserRole => {
  if (username.includes('admin') || username.includes('super')) return 'admin';
  if (username.includes('trainer') || username.includes('instructor')) return 'trainer';
  if (username.includes('principal') || username.includes('head')) return 'principal';
  if (username.includes('cluster') || username.includes('lead')) return 'cluster_lead';
  return 'teacher';
};

export const apiService = {
  async authenticateUser(username: string, password: string): Promise<User | null> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_user_get_users_by_field',
          field: 'username',
          values: [username],
        },
      });

      if (response.data && response.data.length > 0) {
        const userData = response.data[0];
        const role = detectUserRole(username);
        
        return {
          id: userData.id.toString(),
          email: userData.email,
          firstname: userData.firstname,
          lastname: userData.lastname,
          fullname: userData.fullname,
          username: userData.username,
          profileimageurl: userData.profileimageurl,
          lastaccess: userData.lastaccess,
          role,
        };
      }
      return null;
    } catch (error) {
      console.error('Error authenticating user:', error);
      throw new Error('Failed to authenticate user');
    }
  },

  async getAllUsers(): Promise<User[]> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_user_get_users',
          criteria: [
            {
              key: 'deleted',
              value: '0'
            }
          ]
        },
      });

      if (response.data && response.data.users && Array.isArray(response.data.users)) {
        return response.data.users.map((user: any) => ({
          id: user.id.toString(),
          email: user.email,
          firstname: user.firstname,
          lastname: user.lastname,
          fullname: user.fullname,
          username: user.username,
          profileimageurl: user.profileimageurl,
          lastaccess: user.lastaccess,
          role: detectUserRole(user.username || ''),
        }));
      }
      return [];
    } catch (error) {
      console.error('Error fetching all users:', error);
      throw new Error('Failed to fetch users');
    }
  },

  async getUserCourses(userId: string): Promise<Course[]> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_enrol_get_users_courses',
          userid: userId,
        },
      });

      if (response.data && Array.isArray(response.data)) {
        return response.data.map((course: any) => ({
          id: course.id.toString(),
          fullname: course.fullname,
          shortname: course.shortname,
          summary: course.summary,
          courseimage: course.courseimage || course.overviewfiles?.[0]?.fileurl,
          progress: Math.floor(Math.random() * 100), // Mock progress
          categoryname: course.categoryname,
          format: course.format,
          startdate: course.startdate,
          enddate: course.enddate,
          visible: course.visible,
          type: ['ILT', 'VILT', 'Self-paced'][Math.floor(Math.random() * 3)] as 'ILT' | 'VILT' | 'Self-paced',
          tags: ['Professional Development', 'Teaching Skills', 'Assessment'],
        }));
      }
      return [];
    } catch (error) {
      console.error('Error fetching courses:', error);
      throw new Error('Failed to fetch courses');
    }
  },

  async getAllCourses(): Promise<Course[]> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_course_get_courses',
        },
      });

      if (response.data && Array.isArray(response.data)) {
        return response.data.map((course: any) => ({
          id: course.id.toString(),
          fullname: course.fullname,
          shortname: course.shortname,
          summary: course.summary,
          courseimage: course.courseimage || course.overviewfiles?.[0]?.fileurl,
          categoryname: course.categoryname,
          format: course.format,
          startdate: course.startdate,
          enddate: course.enddate,
          visible: course.visible,
          type: ['ILT', 'VILT', 'Self-paced'][Math.floor(Math.random() * 3)] as 'ILT' | 'VILT' | 'Self-paced',
          tags: ['Professional Development', 'Teaching Skills', 'Assessment'],
        }));
      }
      return [];
    } catch (error) {
      console.error('Error fetching all courses:', error);
      throw new Error('Failed to fetch courses');
    }
  },

  async getCourseEnrollments(courseId: string): Promise<any[]> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_enrol_get_enrolled_users',
          courseid: courseId,
        },
      });

      if (response.data && Array.isArray(response.data)) {
        return response.data.map((enrollment: any) => ({
          id: enrollment.id.toString(),
          userid: enrollment.id.toString(),
          fullname: enrollment.fullname,
          email: enrollment.email,
          timeenrolled: enrollment.firstaccess || Date.now() / 1000,
          progress: Math.floor(Math.random() * 100),
        }));
      }
      return [];
    } catch (error) {
      console.error('Error fetching course enrollments:', error);
      return [];
    }
  },

  async getUserProgress(userId: string, courseId: string): Promise<number> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_completion_get_activities_completion_status',
          courseid: courseId,
          userid: userId,
        },
      });

      // Mock progress calculation
      return Math.floor(Math.random() * 100);
    } catch (error) {
      console.error('Error fetching user progress:', error);
      return 0;
    }
  },

  async getCourseCategories(): Promise<any[]> {
    try {
      const response = await api.get('', {
        params: {
          wsfunction: 'core_course_get_categories',
        },
      });

      if (response.data && Array.isArray(response.data)) {
        return response.data;
      }
      return [];
    } catch (error) {
      console.error('Error fetching course categories:', error);
      return [];
    }
  },
};