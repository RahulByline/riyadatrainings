export interface User {
  id: string;
  email: string;
  firstname: string;
  lastname: string;
  fullname: string;
  username?: string;
  profileimageurl?: string;
  lastaccess?: number;
  role?: UserRole;
}

export interface Course {
  id: string;
  fullname: string;
  shortname: string;
  summary?: string;
  courseimage?: string;
  progress?: number;
  categoryname?: string;
  format?: string;
  startdate?: number;
  enddate?: number;
  visible?: boolean;
  tags?: string[];
  type?: 'ILT' | 'VILT' | 'Self-paced';
}

export interface ApiResponse<T> {
  data: T;
  error?: string;
}

export type UserRole = 'teacher' | 'trainer' | 'principal' | 'cluster_lead' | 'admin';

export interface DashboardStats {
  totalCourses: number;
  completedCourses: number;
  inProgressCourses: number;
  upcomingSessions: number;
  achievements: number;
}

export interface Session {
  id: string;
  title: string;
  date: string;
  time: string;
  type: 'ILT' | 'VILT';
  trainer: string;
  status: 'upcoming' | 'completed' | 'cancelled';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  earnedDate: string;
  category: string;
}