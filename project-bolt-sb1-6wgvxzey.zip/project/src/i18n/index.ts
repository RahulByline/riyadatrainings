import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Navigation
      home: 'Home',
      about: 'About',
      courses: 'Courses',
      login: 'Login',
      logout: 'Logout',
      
      // Hero Section
      heroTitle: 'Transform Education Through Excellence',
      heroSubtitle: 'Empowering teachers with world-class training programs',
      exploreBtn: 'Explore Courses',
      getStarted: 'Get Started',
      
      // About Section
      aboutTitle: 'About Riyada Academy',
      aboutDescription: 'Leading the future of education through structured role-based learning and comprehensive teacher development programs.',
      
      // Course Categories
      coursesTitle: 'Course Categories',
      coursesSubtitle: 'Discover our comprehensive training programs',
      
      // Access Areas
      accessTitle: 'Access Your Dashboard',
      accessSubtitle: 'Select your role to continue',
      
      // Roles
      teacher: 'Teacher',
      trainer: 'Trainer',
      principal: 'School Principal',
      clusterLead: 'Cluster Lead',
      admin: 'Super Admin',
      
      // Login
      loginTitle: 'Welcome Back',
      username: 'Username',
      password: 'Password',
      loginBtn: 'Log in',
      lostPassword: 'Lost password?',
      firstTime: 'Is this your first time here?',
      createAccount: 'Create new account',
      
      // Dashboard Common
      welcome: 'Welcome back',
      dashboard: 'Dashboard',
      profile: 'Profile',
      settings: 'Settings',
      
      // Teacher Dashboard
      myLearning: 'My Learning Path',
      courseProgress: 'Course Progress',
      recommendations: 'Recommended Courses',
      upcomingSessions: 'Upcoming Sessions',
      achievements: 'Achievements',
      
      // Trainer Dashboard
      sessionsDelivered: 'Sessions Delivered',
      trainerRating: 'Trainer Rating',
      createSession: 'Create Session',
      peerFeedback: 'Peer Feedback',
      
      // Admin Dashboard
      analytics: 'Analytics',
      userManagement: 'User Management',
      reports: 'Reports',
      systemHealth: 'System Health',
      
      // Common
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      save: 'Save',
      cancel: 'Cancel',
      edit: 'Edit',
      delete: 'Delete',
      view: 'View',
      download: 'Download',
    }
  },
  ar: {
    translation: {
      // Navigation
      home: 'الرئيسية',
      about: 'حول',
      courses: 'الدورات',
      login: 'تسجيل الدخول',
      logout: 'تسجيل الخروج',
      
      // Hero Section
      heroTitle: 'تحويل التعليم من خلال التميز',
      heroSubtitle: 'تمكين المعلمين ببرامج تدريبية عالمية المستوى',
      exploreBtn: 'استكشف الدورات',
      getStarted: 'ابدأ الآن',
      
      // About Section
      aboutTitle: 'حول أكاديمية ريادة',
      aboutDescription: 'قيادة مستقبل التعليم من خلال التعلم المنظم القائم على الأدوار وبرامج تطوير المعلمين الشاملة.',
      
      // Course Categories
      coursesTitle: 'فئات الدورات',
      coursesSubtitle: 'اكتشف برامجنا التدريبية الشاملة',
      
      // Access Areas
      accessTitle: 'الوصول إلى لوحة التحكم',
      accessSubtitle: 'اختر دورك للمتابعة',
      
      // Roles
      teacher: 'معلم',
      trainer: 'مدرب',
      principal: 'مدير مدرسة',
      clusterLead: 'قائد المجموعة',
      admin: 'مدير النظام',
      
      // Login
      loginTitle: 'مرحباً بعودتك',
      username: 'اسم المستخدم',
      password: 'كلمة المرور',
      loginBtn: 'تسجيل الدخول',
      lostPassword: 'نسيت كلمة المرور؟',
      firstTime: 'هل هذه المرة الأولى هنا؟',
      createAccount: 'إنشاء حساب جديد',
      
      // Dashboard Common
      welcome: 'مرحباً بعودتك',
      dashboard: 'لوحة التحكم',
      profile: 'الملف الشخصي',
      settings: 'الإعدادات',
      
      // Teacher Dashboard
      myLearning: 'مسار التعلم الخاص بي',
      courseProgress: 'تقدم الدورة',
      recommendations: 'الدورات الموصى بها',
      upcomingSessions: 'الجلسات القادمة',
      achievements: 'الإنجازات',
      
      // Trainer Dashboard
      sessionsDelivered: 'الجلسات المقدمة',
      trainerRating: 'تقييم المدرب',
      createSession: 'إنشاء جلسة',
      peerFeedback: 'تقييم الأقران',
      
      // Admin Dashboard
      analytics: 'التحليلات',
      userManagement: 'إدارة المستخدمين',
      reports: 'التقارير',
      systemHealth: 'صحة النظام',
      
      // Common
      loading: 'جاري التحميل...',
      error: 'خطأ',
      success: 'نجح',
      save: 'حفظ',
      cancel: 'إلغاء',
      edit: 'تعديل',
      delete: 'حذف',
      view: 'عرض',
      download: 'تحميل',
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    debug: false,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;